import { Component } from '@angular/core';
import { ProfileCard } from './profile-card/profile-card';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ProfileCard],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  fullName = 'Louisse Ken W. Tiosejo';
  location = 'San Fernando, Pampanga';
  email = 'gamingsetsu10@gmail.com';
  phone = '0949 817 7265';


  hobbies = ['Watching Formula One race', 'Watching Filipino Movies', 'Playing online games']

  skills = [
    'HTML and CSS',
    'Photoshop',
    'Canva',
    'After Effect'
  ];

  message = 'Welcome to my profile!';
  clickCount = 0;

  // Five start lights. Clicks 1-5 light them red one by one,
  // click 6 turns them all green, click 7 starts the cycle again.
  lights = [1, 2, 3, 4, 5];

  get lit() {
    return this.clickCount % 7;
  }

  showMessage() {
    this.clickCount++;
    this.message = `You clicked the button ${this.clickCount} time(s).`;
  }
}
