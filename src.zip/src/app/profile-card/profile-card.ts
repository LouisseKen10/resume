import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-profile-card',
  styleUrl: './profile-card.css',
  templateUrl: './profile-card.html',
})
export class ProfileCard {cardTitle = 'A Little About Me';
  description = 'I love Watching Formula One and I love the team Williams';}
